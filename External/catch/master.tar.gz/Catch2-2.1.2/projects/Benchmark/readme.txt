This is very much a work in progress.
The past results are standardized to a developer's machine,
the benchmarking script is basic and there are only 3 benchmarks,
but this should get better in time. For now, at least there is something to go by.
